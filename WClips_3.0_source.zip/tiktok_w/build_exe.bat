@echo off
setlocal
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --onefile --noconsole --name "WClips" --icon "static\assets\wclips.ico" --collect-all google.auth --collect-all google.oauth2 --add-data "templates;templates" --add-data "static;static" main.py
if errorlevel 1 goto error
echo.
echo EXE READY: dist\WClips.exe
echo To create Setup.exe, install Inno Setup 6 and run: iscc installer.iss
pause
exit /b 0
:error
echo Build failed. Check Python and pip installation.
pause
exit /b 1
