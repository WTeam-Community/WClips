"""Запуск WClips в отдельном окне браузера."""
import os, socket, subprocess, sys, threading, time, webbrowser
if sys.stdout is None: sys.stdout = open(os.devnull, "w")
if sys.stderr is None: sys.stderr = open(os.devnull, "w")
from werkzeug.serving import make_server
import app as wclips

def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1",0)); return s.getsockname()[1]

def find_browser():
    roots=[os.environ.get(x,"") for x in ("PROGRAMFILES(X86)","PROGRAMFILES","LOCALAPPDATA")]
    for root in roots:
        for rel in (("Microsoft","Edge","Application","msedge.exe"),("Google","Chrome","Application","chrome.exe")):
            path=os.path.join(root,*rel)
            if os.path.isfile(path): return path
    return None

def main():
    wclips.init_db()
    port=8765
    server=make_server("127.0.0.1",port,wclips.app,threaded=True)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url=f"http://localhost:{port}/"
    browser=find_browser()
    if browser:
        profile=os.path.join(wclips.DATA,"window-profile")
        subprocess.Popen([browser,f"--app={url}",f"--user-data-dir={profile}","--window-size=1400,950","--no-first-run"])
    else: webbrowser.open(url)
    try:
        while True: time.sleep(3600)
    except KeyboardInterrupt: pass
    finally: server.shutdown()

if __name__=="__main__": main()
