const $=s=>document.querySelector(s);
const api=async(url,opts={})=>{const r=await fetch(url,opts);const d=await r.json();if(!r.ok)throw new Error(d.error||"Ошибка запроса");return d};
const post=(url,data)=>api(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
let S={},REG={},mode="for-you",activeCommentVideo=null,searchTimer=null;
const modal=id=>$("#"+id).classList.add("open");
const closeModal=el=>el.closest(".modal")?.classList.remove("open");
function applySettings(){
 document.documentElement.style.setProperty("--accent",S.accent||"#64748b");
 document.documentElement.dataset.theme=S.theme||"dark";
 const themeControl=$("#theme"); if(themeControl) themeControl.value=S.theme||"dark";
 const fs=$("#fontstyle");
 if(S.font_file){fs.textContent=`@font-face{font-family:WCustom;src:url('/media/fonts/${S.font_file}')}body{font-family:WCustom,Manrope,sans-serif}`}
 else if(S.font_family){fs.textContent=`body{font-family:"${S.font_family}",Manrope,sans-serif}`}
 else fs.textContent="";
 $("#region").value=S.region;$("#accent").value=S.accent;$("#fontFamily").value=S.font_family||"";
 $("#displayName").value=S.display_name||"WClips user";$("#username").value=S.username||"wclips_user";$("#bio").value=S.bio||"";
 $("#profileName").textContent=S.display_name||"WClips user";$("#profileHandle").textContent="@"+(S.username||"wclips_user");
 $("#profileBio").textContent=S.bio||"Пока нет описания профиля.";
 $("#profileSub").textContent=S.google_email||"Бесплатный локальный профиль";
}
function switchMode(next){
 mode=next;document.querySelectorAll("[data-mode]").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));
 const titles={"for-you":"Для вас","latest":"Новое","favorites":"Избранное"};
 $("#feedTitle").textContent=titles[mode]||"Поиск";
 loadFeed();
}
function formatTags(tags){return (tags||"").split(",").filter(Boolean).map(t=>"#"+t.trim().replace(/^#/,"")).join(" ")}
function createCard(v){
 const card=document.createElement("article");card.className="video-card";
 const stage=document.createElement("div");stage.className="video-stage";
 const video=document.createElement("video");video.src="/media/uploads/"+encodeURIComponent(v.file);video.controls=true;video.playsInline=true;video.preload="metadata";video.loop=true;stage.append(video);
 const overlay=document.createElement("div");overlay.className="video-overlay";overlay.innerHTML='<span class="play-hint">WCLIPS · SHORT VIDEO</span>';stage.append(overlay);
 const details=document.createElement("div");details.className="video-details";
 const author=document.createElement("div");author.className="author-line";author.innerHTML=`<div class="avatar">W</div><div><b></b><small>Автор видео</small></div>`;author.querySelector("b").textContent="@"+(v.author||"user").replace(/^@/,"");
 author.style.cursor="pointer";author.title="Подписаться на автора";author.onclick=async()=>{try{const r=await post("/api/follow",{author:v.author});author.querySelector("small").textContent=r.following?"Вы подписаны":"Автор видео"}catch(e){}};
 const title=document.createElement("h2");title.textContent=v.title;
 const tags=document.createElement("div");tags.className="tags";tags.textContent=formatTags(v.tags);
 const stats=document.createElement("div");stats.className="stats-line";stats.textContent=`▶ ${v.views||0} просмотров · ♥ ${v.likes||0} лайков`;
 const actions=document.createElement("div");actions.className="video-actions";
 const like=document.createElement("button");like.className="action";like.textContent="♥ Нравится";
 let liked=!!v.liked;like.classList.toggle("selected",liked);like.textContent=liked?"♥ Понравилось":"♥ Нравится";like.onclick=async()=>{liked=!liked;try{const r=await post(`/api/like/${v.id}`,{liked});like.classList.toggle("selected",liked);like.textContent=liked?"♥ Понравилось":"♥ Нравится";stats.textContent=`▶ ${v.views||0} просмотров · ♥ ${r.likes} лайков`}catch(err){alert(err.message)}};
 const fav=document.createElement("button");fav.className="action"+(v.favorite?" selected":"");fav.textContent=v.favorite?"★ В избранном":"☆ В избранное";fav.onclick=async()=>{const r=await post(`/api/favorite/${v.id}`,{});fav.classList.toggle("selected",r.saved);fav.textContent=r.saved?"★ В избранном":"☆ В избранное";if(mode==="favorites"&&!r.saved)card.remove()};
 const comment=document.createElement("button");comment.className="action";comment.textContent="▤ Комментарии";comment.onclick=()=>openComments(v.id);
 const share=document.createElement("button");share.className="action";share.textContent="↗ Поделиться";share.onclick=async()=>{const text=location.origin+"/#video-"+v.id;try{await navigator.clipboard.writeText(text);share.textContent="✓ Скопировано"}catch{share.textContent="ID: "+v.id}};
 actions.append(like,fav,comment,share);details.append(author,title,tags,stats,actions);card.append(stage,details);
 const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting&&e.intersectionRatio>.65){video.play().catch(()=>{});post(`/api/view/${v.id}`,{fraction:.7}).catch(()=>{});}else video.pause()}),{threshold:[.1,.65]});observer.observe(card);
 return card;
}
async function loadFeed(){
 const feed=$("#feed");feed.innerHTML='<div class="loading">Загружаем ленту…</div>';
 try{
  const q=$("#search").value.trim();const data=await api(`/api/feed?mode=${encodeURIComponent(mode)}&q=${encodeURIComponent(q)}`);
  feed.innerHTML="";
  if(!data.items.length){
   const empty=document.createElement("div");empty.className="empty-state";
   empty.innerHTML='<div class="empty-symbol">▶</div><h2>Здесь пока тихо</h2><p>В ленте нет загруженных видео. Добавь своё первое видео — оно появится здесь. Мы не подставляем фальшивые ролики или заглушки.</p><button class="primary" id="emptyUpload">＋ Загрузить видео</button>';
   feed.append(empty);$("#emptyUpload").onclick=()=>modal("mUpload");return;
  }
  data.items.forEach(v=>feed.append(createCard(v)));
  $("#feedMeta").textContent=`${data.items.length} видео`;
 }catch(e){feed.innerHTML=`<div class="empty-state"><h2>Не удалось загрузить ленту</h2><p>${e.message}</p></div>`}
}
async function openComments(id){
 activeCommentVideo=id;modal("mComments");$("#commentList").innerHTML="Загрузка…";
 try{const r=await api(`/api/comments/${id}`);$("#commentList").innerHTML="";if(!r.items.length){$("#commentList").textContent="Пока нет комментариев. Начни обсуждение!"}
 r.items.forEach(c=>{const el=document.createElement("div");el.className="comment";const b=document.createElement("b");b.textContent=c.author;const p=document.createElement("p");p.textContent=c.body;el.append(b,p);$("#commentList").append(el)})}catch(e){$("#commentList").textContent=e.message}
}
async function openStudio(){
 modal("mStudio");const list=$("#studioList");list.textContent="Загружаем публикации…";
 try{const data=await api("/api/studio/videos");list.innerHTML="";
  if(!data.items.length){list.textContent="У тебя пока нет опубликованных видео.";return}
  data.items.forEach(v=>{
   const row=document.createElement("div");row.className="studio-item";
   const info=document.createElement("div");info.className="studio-info";
   const name=document.createElement("b");name.textContent=v.title;
   const meta=document.createElement("small");meta.textContent=`♥ ${v.likes} · ▶ ${v.views} просмотров`;
   info.append(name,meta);
   const edit=document.createElement("button");edit.className="secondary";edit.textContent="Изменить";
   edit.onclick=async()=>{const title=prompt("Название видео",v.title);if(title===null)return;const tags=prompt("Теги через запятую",v.tags||"");if(tags===null)return;try{await post(`/api/studio/video/${v.id}`,{title,tags});openStudio();loadFeed()}catch(e){alert(e.message)}};
   const del=document.createElement("button");del.className="danger";del.textContent="Удалить";
   del.onclick=async()=>{if(!confirm(`Удалить видео «${v.title}»? Это действие нельзя отменить.`))return;try{await api(`/api/studio/video/${v.id}`,{method:"DELETE"});openStudio();loadFeed()}catch(e){alert(e.message)}};
   row.append(info,edit,del);list.append(row);
  });
 }catch(e){list.textContent=e.message}
}
async function saveSettings(data){const r=await post("/api/settings",data);S=r.settings;applySettings();loadFeed()}
document.querySelectorAll("[data-mode]").forEach(b=>b.onclick=()=>switchMode(b.dataset.mode));
["#bUpload","#navUpload","#mobileUpload"].forEach(s=>$(s).onclick=()=>modal("mUpload"));
["#bSettings","#navSettings","#mobileSettings"].forEach(s=>$(s).onclick=()=>modal("mSettings"));
$("#navStudio").onclick=openStudio;
$("#navProfile").onclick=async()=>{const r=await api("/api/bootstrap");$("#statVideos").textContent=r.stats.videos;const f=await api("/api/feed?mode=favorites");$("#statFavorites").textContent=f.items.length;modal("mProfile")};
$("#profileEdit").onclick=()=>{closeModal($("#mProfile"));modal("mSettings")};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.remove("open")}));
$("#videoFile").onchange=e=>$("#fileName").textContent=e.target.files[0]?.name||"Файл не выбран";
$("#fUpload").onsubmit=async e=>{e.preventDefault();const btn=e.target.querySelector("button.primary");btn.disabled=true;btn.textContent="Загрузка…";try{await api("/api/upload",{method:"POST",body:new FormData(e.target)});e.target.reset();$("#fileName").textContent="Файл не выбран";closeModal(e.target);switchMode("latest")}catch(err){$("#uploadHint").textContent=err.message}finally{btn.disabled=false;btn.innerHTML='Опубликовать <span>↗</span>'}};
$("#region").onchange=e=>saveSettings({region:e.target.value});
$("#accent").onchange=e=>saveSettings({accent:e.target.value});
$("#theme").onchange=e=>saveSettings({theme:e.target.value});
$("#fontFamily").onchange=e=>saveSettings({font_family:e.target.value});
$("#displayName").onchange=e=>saveSettings({display_name:e.target.value});
$("#username").onchange=e=>saveSettings({username:e.target.value});
$("#bio").onchange=e=>saveSettings({bio:e.target.value});
$("#fontFile").onchange=async e=>{if(!e.target.files[0])return;const fd=new FormData();fd.append("font",e.target.files[0]);try{const r=await api("/api/font",{method:"POST",body:fd});S=r.settings;applySettings()}catch(err){alert(err.message)}};
$("#fontReset").onclick=async()=>{const r=await post("/api/font/reset",{});S=r.settings;applySettings()};
$("#commentForm").onsubmit=async e=>{e.preventDefault();const input=$("#commentText");try{await post(`/api/comments/${activeCommentVideo}`,{body:input.value});input.value="";openComments(activeCommentVideo)}catch(err){alert(err.message)}};
$("#search").onkeydown=e=>{if(e.key==="Enter"){switchMode(mode)}};
$("#search").oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(loadFeed,350)};
async function init(){
 const r=await api("/api/bootstrap");S=r.settings;REG=r.regions;
 $("#region").innerHTML=Object.entries(REG).map(([k,v])=>`<option value="${k}">${v}</option>`).join("");
 applySettings();loadFeed();checkForUpdates();setupGoogleSignIn();
}
async function checkForUpdates(){
 try{const v=await api("/api/version");if(v.update_available){$("#updateNotice").hidden=false;$("#updateButton").onclick=()=>window.open(v.update_url,"_blank","noopener")}}catch(e){}
}
async function setupGoogleSignIn(){
 const cfg=await api("/api/auth/config").catch(()=>({enabled:false}));
 const hint=$("#googleHint"),slot=$("#googleSignIn");
 if(!cfg.enabled){hint.textContent="Владелец WClips должен добавить WCLIPS_GOOGLE_CLIENT_ID из Google Cloud Console. Без этого Google-вход не активируется.";return}
 hint.textContent="Войдите с помощью Google. Данные профиля сохраняются локально на этом компьютере.";
 const waitForGoogle=()=>{if(!window.google?.accounts?.id){setTimeout(waitForGoogle,250);return}
  google.accounts.id.initialize({client_id:cfg.client_id,callback:async(response)=>{
   try{const result=await post("/api/auth/google",{credential:response.credential});S=result.settings;applySettings();hint.textContent="Вы вошли как "+result.email;$("#profileSub").textContent=result.email}
   catch(err){hint.textContent=err.message}
  }});
  google.accounts.id.renderButton(slot,{theme:document.documentElement.dataset.theme==="dark"?"filled_black":"outline",size:"large",shape:"pill",text:"signin_with",locale:"ru"});
 };
 waitForGoogle();
}
init().catch(e=>{$("#feed").textContent=e.message});


// Масштабирование: удерживайте CTRL + правую кнопку мыши и двигайте указатель вверх/вниз.
(()=>{
 let dragging=false,startY=0,startZoom=100,zoom=100;
 const apply=()=>{document.documentElement.style.zoom=(zoom/100);};
 document.addEventListener("contextmenu",e=>{if(e.ctrlKey)e.preventDefault()});
 document.addEventListener("pointerdown",e=>{if(e.button===2&&e.ctrlKey){dragging=true;startY=e.clientY;startZoom=zoom;document.body.classList.add("zoom-dragging");e.preventDefault()}});
 document.addEventListener("pointermove",e=>{if(!dragging)return;zoom=Math.max(70,Math.min(140,startZoom+(startY-e.clientY)*0.35));apply();});
 document.addEventListener("pointerup",e=>{if(e.button===2&&dragging){dragging=false;document.body.classList.remove("zoom-dragging");localStorage.setItem("wclips-zoom",String(zoom))}});
 const saved=Number(localStorage.getItem("wclips-zoom"));if(saved>=70&&saved<=140){zoom=saved;apply()}
})();
