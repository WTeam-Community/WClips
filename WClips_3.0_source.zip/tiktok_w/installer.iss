[Setup]
AppId={{A90B56A1-1E6F-4C65-9F20-7A81D8C3A2B4}
AppName=WClips
AppVersion=3.0.0
AppPublisher=WClips
DefaultDirName={autopf}\WClips
DefaultGroupName=WClips
OutputDir=installer_output
OutputBaseFilename=WClips-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=static\assets\wclips.ico
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64

[Files]
Source: "dist\WClips.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\WClips"; Filename: "{app}\WClips.exe"
Name: "{autodesktop}\WClips"; Filename: "{app}\WClips.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные ярлыки:"

[Run]
Filename: "{app}\WClips.exe"; Description: "Запустить WClips"; Flags: nowait postinstall skipifsilent
