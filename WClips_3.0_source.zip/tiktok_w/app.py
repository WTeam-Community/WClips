"""WClips — локальная короткоформатная видеоплатформа."""
import math, os, re, sqlite3, sys, time, uuid, json, urllib.request
from flask import Flask, jsonify, request, render_template, g, send_from_directory

BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    DATA = os.path.join(os.environ.get("APPDATA", os.path.dirname(sys.executable)), "WClips")
else:
    DATA = os.path.dirname(os.path.abspath(__file__))
UP = os.path.join(DATA, "uploads")
FONTS = os.path.join(DATA, "fonts")
DB = os.path.join(DATA, "wclips.db")
for folder in (DATA, UP, FONTS):
    os.makedirs(folder, exist_ok=True)

app = Flask(__name__, template_folder=os.path.join(BASE, "templates"),
            static_folder=os.path.join(BASE, "static"))
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024
CURRENT_VERSION = "3.0.0"
GITHUB_REPO = "https://github.com/WTeam-Community/WClips"
GOOGLE_CLIENT_ID = os.environ.get("WCLIPS_GOOGLE_CLIENT_ID", "").strip()
if not GOOGLE_CLIENT_ID:
    try:
        with open(os.path.join(DATA, "google_client_id.txt"), encoding="utf-8") as _f:
            GOOGLE_CLIENT_ID = _f.read().strip()
    except OSError:
        pass

VIDEO_EXT = {".mp4", ".webm", ".mov", ".m4v"}
FONT_EXT = {".ttf", ".otf", ".woff", ".woff2"}
REGIONS = {"ALL":"Весь мир", "RU":"Россия", "LV":"Латвия", "KZ":"Казахстан",
           "BY":"Беларусь", "UA":"Украина", "US":"США", "GB":"Великобритания", "DE":"Германия"}
DEFAULTS = {"region":"ALL", "accent":"#64748b", "theme":"dark", "font_file":"", "font_family":"", "display_name":"WClips user", "username":"wclips_user", "bio":""}

def connect():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    conn = g.pop("db", None)
    if conn: conn.close()

def init_db():
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS videos(
      id INTEGER PRIMARY KEY, title TEXT NOT NULL, tags TEXT DEFAULT '', region TEXT DEFAULT 'ALL',
      file TEXT NOT NULL, author TEXT DEFAULT 'WClips user', created_at REAL,
      likes INTEGER DEFAULT 0, views INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS interests(tag TEXT PRIMARY KEY, weight REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS comments(
      id INTEGER PRIMARY KEY, video_id INTEGER NOT NULL, author TEXT NOT NULL,
      body TEXT NOT NULL, created_at REAL, FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS favorites(video_id INTEGER PRIMARY KEY, created_at REAL,
      FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS likes(video_id INTEGER NOT NULL, device_user TEXT NOT NULL DEFAULT 'local',
      created_at REAL, PRIMARY KEY(video_id, device_user),
      FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS follows(author TEXT NOT NULL, follower TEXT NOT NULL DEFAULT 'local',
      created_at REAL, PRIMARY KEY(author, follower));
    """)
    # Migrate older installs safely.
    cols = {r[1] for r in c.execute("PRAGMA table_info(videos)")}
    if "region" not in cols: c.execute("ALTER TABLE videos ADD COLUMN region TEXT DEFAULT 'ALL'")
    c.commit(); c.close()

@app.get("/")
def index():
    return render_template("index.html", google_client_id=GOOGLE_CLIENT_ID, app_version=CURRENT_VERSION)

@app.get("/media/<kind>/<path:name>")
def media(kind, name):
    if kind == "uploads": folder = UP
    elif kind == "fonts": folder = FONTS
    else: return "", 404
    return send_from_directory(folder, name, conditional=True)

def settings():
    result = dict(DEFAULTS)
    for r in connect().execute("SELECT key,value FROM settings"):
        result[r["key"]] = r["value"]
    return result

def save_setting(key, value):
    connect().execute("""INSERT INTO settings(key,value) VALUES(?,?)
      ON CONFLICT(key) DO UPDATE SET value=excluded.value""", (key, value))
    connect().commit()

def add_interest(tags, amount):
    for tag in [x.strip().lower()[:32] for x in tags.split(",") if x.strip()]:
        connect().execute("""INSERT INTO interests(tag,weight) VALUES(?,?)
          ON CONFLICT(tag) DO UPDATE SET weight=MAX(-2,MIN(10,weight+?))""",
          (tag, amount, amount))
    connect().commit()

@app.get("/api/bootstrap")
def bootstrap():
    return jsonify(settings=settings(), regions=REGIONS,
        stats={"videos":connect().execute("SELECT COUNT(*) FROM videos").fetchone()[0],
               "my_videos":connect().execute("SELECT COUNT(*) FROM videos WHERE author=?",(settings()["display_name"],)).fetchone()[0]})

@app.post("/api/settings")
def update_settings():
    data = request.get_json(force=True)
    if data.get("region") in REGIONS: save_setting("region", data["region"])
    if data.get("theme") in ("dark", "light"): save_setting("theme", data["theme"])
    if re.fullmatch(r"#[0-9a-fA-F]{6}", data.get("accent", "")): save_setting("accent", data["accent"])
    if "font_family" in data:
        save_setting("font_family", re.sub(r"[^\w ,\-]", "", data["font_family"])[:80])
        save_setting("font_file", "")
    if "display_name" in data:
        save_setting("display_name", re.sub(r"[^\w @.\-]", "", data["display_name"])[:32] or "WClips user")
    if "username" in data:
        save_setting("username", re.sub(r"[^a-zA-Z0-9_.]", "", str(data["username"])).lower()[:24] or "wclips_user")
    if "bio" in data:
        save_setting("bio", str(data["bio"])[:160])
    return jsonify(settings=settings())

@app.post("/api/font")
def upload_font():
    f = request.files.get("font")
    ext = os.path.splitext(f.filename)[1].lower() if f else ""
    if not f or ext not in FONT_EXT: return jsonify(error="Поддерживаются TTF, OTF, WOFF и WOFF2"), 400
    name = uuid.uuid4().hex + ext
    f.save(os.path.join(FONTS, name))
    save_setting("font_file", name); save_setting("font_family", "")
    return jsonify(settings=settings())

@app.post("/api/font/reset")
def reset_font():
    save_setting("font_file", ""); save_setting("font_family", "")
    return jsonify(settings=settings())

@app.get("/api/feed")
def feed():
    region = request.args.get("region") or settings()["region"]
    query = request.args.get("q", "").strip().lower()[:80]
    mode = request.args.get("mode", "for-you")
    rows = connect().execute("SELECT * FROM videos ORDER BY created_at DESC").fetchall()
    interests = {r["tag"]:r["weight"] for r in connect().execute("SELECT * FROM interests")}
    favorites = {r[0] for r in connect().execute("SELECT video_id FROM favorites")}
    liked_ids = {r[0] for r in connect().execute("SELECT video_id FROM likes WHERE device_user='local'")}
    my_name = settings()["display_name"]
    items = []
    for r in rows:
        if region != "ALL" and r["region"] not in (region, "ALL"): continue
        if query and query not in (r["title"]+" "+r["tags"]+" "+r["author"]).lower(): continue
        if mode == "favorites" and r["id"] not in favorites: continue
        tags = [x.strip() for x in r["tags"].split(",") if x.strip()]
        age_h = max(0, (time.time()-r["created_at"])/3600)
        freshness = 0.5 ** (age_h/72)
        affinity = sum(interests.get(t,0) for t in tags)
        score = freshness + 0.12*affinity + math.log1p(r["likes"])*0.04
        items.append((score, r))
    if mode == "for-you": items.sort(key=lambda x: -x[0])
    else: items.sort(key=lambda x: -x[1]["created_at"])
    return jsonify(items=[{"id":r["id"],"title":r["title"],"tags":r["tags"],
        "file":r["file"],"author":r["author"],"likes":r["likes"],"views":r["views"],
        "created_at":r["created_at"],"favorite":r["id"] in favorites,
        "liked":r["id"] in liked_ids,"is_mine":r["author"] == my_name} for _,r in items[:100]])

@app.post("/api/upload")
def upload():
    f = request.files.get("video")
    ext = os.path.splitext(f.filename)[1].lower() if f else ""
    if not f or ext not in VIDEO_EXT: return jsonify(error="Выберите видео MP4, WEBM, MOV или M4V"), 400
    title = (request.form.get("title") or "").strip()[:120]
    if not title: return jsonify(error="Добавьте название видео"), 400
    tags = re.sub(r"[^\w,\- #]", "", request.form.get("tags","").lower())[:180]
    name = uuid.uuid4().hex + ext
    f.save(os.path.join(UP, name))
    s = settings()
    cur = connect().execute("""INSERT INTO videos(title,tags,region,file,author,created_at)
        VALUES(?,?,?,?,?,?)""", (title,tags,s["region"],name,s["display_name"],time.time()))
    connect().commit()
    return jsonify(ok=True,id=cur.lastrowid)

@app.post("/api/like/<int:vid>")
def like(vid):
    data=request.get_json(force=True); liked=bool(data.get("liked"))
    conn=connect()
    if not conn.execute("SELECT id FROM videos WHERE id=?",(vid,)).fetchone():
        return jsonify(error="Видео не найдено"),404
    exists=conn.execute("SELECT 1 FROM likes WHERE video_id=? AND device_user='local'",(vid,)).fetchone()
    if liked and not exists:
        conn.execute("INSERT INTO likes(video_id,device_user,created_at) VALUES(?,?,?)",(vid,"local",time.time()))
        conn.execute("UPDATE videos SET likes=likes+1 WHERE id=?",(vid,))
    elif not liked and exists:
        conn.execute("DELETE FROM likes WHERE video_id=? AND device_user='local'",(vid,))
        conn.execute("UPDATE videos SET likes=MAX(0,likes-1) WHERE id=?",(vid,))
    conn.commit()
    r=conn.execute("SELECT tags,likes FROM videos WHERE id=?",(vid,)).fetchone()
    if r: add_interest(r["tags"],0.6 if liked else -0.6)
    return jsonify(ok=True, liked=liked, likes=r["likes"])

@app.post("/api/view/<int:vid>")
def view(vid):
    data=request.get_json(silent=True) or {}
    frac=max(0,min(1,float(data.get("fraction",0))))
    r=connect().execute("SELECT tags FROM videos WHERE id=?",(vid,)).fetchone()
    if r:
        connect().execute("UPDATE videos SET views=views+1 WHERE id=?",(vid,)); connect().commit()
        add_interest(r["tags"],0.25 if frac>.65 else -0.1 if frac<.15 else 0)
    return jsonify(ok=True)

@app.get("/api/comments/<int:vid>")
def comments(vid):
    rows=connect().execute("SELECT * FROM comments WHERE video_id=? ORDER BY created_at DESC",(vid,)).fetchall()
    return jsonify(items=[dict(id=r["id"],author=r["author"],body=r["body"],created_at=r["created_at"]) for r in rows])

@app.post("/api/comments/<int:vid>")
def add_comment(vid):
    data=request.get_json(force=True); body=(data.get("body") or "").strip()[:500]
    if not body: return jsonify(error="Напишите комментарий"),400
    s=settings()
    if not connect().execute("SELECT id FROM videos WHERE id=?",(vid,)).fetchone(): return jsonify(error="Видео не найдено"),404
    connect().execute("INSERT INTO comments(video_id,author,body,created_at) VALUES(?,?,?,?)",
        (vid,s["display_name"],body,time.time())); connect().commit()
    return jsonify(ok=True)

@app.post("/api/favorite/<int:vid>")
def favorite(vid):
    conn=connect()
    if not conn.execute("SELECT id FROM videos WHERE id=?",(vid,)).fetchone(): return jsonify(error="Видео не найдено"),404
    exists=conn.execute("SELECT 1 FROM favorites WHERE video_id=?",(vid,)).fetchone()
    if exists: conn.execute("DELETE FROM favorites WHERE video_id=?",(vid,)); saved=False
    else: conn.execute("INSERT INTO favorites(video_id,created_at) VALUES(?,?)",(vid,time.time())); saved=True
    conn.commit()
    return jsonify(ok=True,saved=saved)

@app.get("/api/studio/videos")
def studio_videos():
    author=settings()["display_name"]
    rows=connect().execute("SELECT id,title,tags,file,likes,views,created_at FROM videos WHERE author=? ORDER BY created_at DESC",(author,)).fetchall()
    return jsonify(items=[dict(r) for r in rows])

@app.post("/api/studio/video/<int:vid>")
def studio_edit_video(vid):
    data=request.get_json(force=True); title=(data.get("title") or "").strip()[:120]
    tags=re.sub(r"[^\\w,\\- #]", "", str(data.get("tags","")).lower())[:180]
    if not title: return jsonify(error="Название не может быть пустым"),400
    cur=connect().execute("UPDATE videos SET title=?,tags=? WHERE id=? AND author=?",
        (title,tags,vid,settings()["display_name"]))
    connect().commit()
    if not cur.rowcount: return jsonify(error="Видео не найдено или принадлежит другому автору"),404
    return jsonify(ok=True)

@app.delete("/api/studio/video/<int:vid>")
def studio_delete_video(vid):
    row=connect().execute("SELECT file FROM videos WHERE id=? AND author=?",(vid,settings()["display_name"])).fetchone()
    if not row: return jsonify(error="Видео не найдено или принадлежит другому автору"),404
    connect().execute("DELETE FROM videos WHERE id=?",(vid,)); connect().commit()
    try: os.remove(os.path.join(UP,row["file"]))
    except OSError: pass
    return jsonify(ok=True)

@app.post("/api/follow")
def follow_author():
    author=str((request.get_json(silent=True) or {}).get("author",""))[:32]
    if not author or author==settings()["display_name"]:
        return jsonify(error="Нельзя подписаться на этот профиль"),400
    conn=connect()
    exists=conn.execute("SELECT 1 FROM follows WHERE author=? AND follower='local'",(author,)).fetchone()
    if exists:
        conn.execute("DELETE FROM follows WHERE author=? AND follower='local'",(author,)); following=False
    else:
        conn.execute("INSERT INTO follows(author,follower,created_at) VALUES(?,'local',?)",(author,time.time())); following=True
    conn.commit()
    return jsonify(ok=True,following=following)

@app.get("/api/search")
def search():
    q=request.args.get("q","").strip()[:80]
    rows=connect().execute("SELECT id,title,tags,author FROM videos WHERE title LIKE ? OR tags LIKE ? OR author LIKE ? ORDER BY created_at DESC LIMIT 20",
        (f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    return jsonify(items=[dict(r) for r in rows])


@app.get("/api/version")
def version_check():
    latest = CURRENT_VERSION
    try:
        url = "https://raw.githubusercontent.com/WTeam-Community/WClips/main/version.json"
        req = urllib.request.Request(url, headers={"User-Agent": "WClips-Version-Checker"})
        with urllib.request.urlopen(req, timeout=3) as response:
            payload = json.loads(response.read(65536).decode("utf-8"))
        latest = str(payload.get("version", CURRENT_VERSION))
    except Exception:
        pass
    def parts(value):
        nums = re.findall(r"\d+", value)
        return tuple(int(x) for x in nums[:4]) or (0,)
    return jsonify(current=CURRENT_VERSION, latest=latest,
                   update_available=parts(latest) > parts(CURRENT_VERSION),
                   update_url=GITHUB_REPO)

@app.get("/api/auth/config")
def google_auth_config():
    return jsonify(enabled=bool(GOOGLE_CLIENT_ID), client_id=GOOGLE_CLIENT_ID)

@app.post("/api/auth/google")
def google_auth():
    if not GOOGLE_CLIENT_ID:
        return jsonify(error="Владелец приложения ещё не настроил Google OAuth Client ID."), 503
    credential = (request.get_json(silent=True) or {}).get("credential", "")
    if not credential:
        return jsonify(error="Google не вернул токен авторизации."), 400
    try:
        from google.oauth2 import id_token
        from google.auth.transport import requests as google_requests
        info = id_token.verify_oauth2_token(credential, google_requests.Request(), GOOGLE_CLIENT_ID)
        if info.get("aud") != GOOGLE_CLIENT_ID:
            raise ValueError("Неверный OAuth audience")
        name = str(info.get("name") or info.get("given_name") or "Google user")[:32]
        email = str(info.get("email") or "")[:254]
        save_setting("display_name", name)
        save_setting("google_name", name)
        save_setting("google_email", email)
        return jsonify(ok=True, name=name, email=email, settings=settings())
    except Exception:
        return jsonify(error="Не удалось подтвердить вход Google. Проверьте OAuth Client ID и настройки домена."), 401

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False)
